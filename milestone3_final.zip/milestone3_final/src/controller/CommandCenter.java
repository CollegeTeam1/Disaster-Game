package controller;

import java.awt.Dimension;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.io.File;
import java.io.IOException;
import java.util.ArrayList;

import javax.sound.sampled.AudioInputStream;
import javax.sound.sampled.AudioSystem;
import javax.sound.sampled.Clip;
import javax.sound.sampled.LineUnavailableException;
import javax.sound.sampled.UnsupportedAudioFileException;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;

import exceptions.CannotTreatException;
import exceptions.IncompatibleTargetException;
import model.disasters.Collapse;
import model.disasters.Disaster;
import model.disasters.Fire;
import model.disasters.GasLeak;
import model.disasters.Infection;
import model.disasters.Injury;
//import eg.edu.guc.supermarket.model.product.GroceryProduct;
import model.events.SOSListener;
import model.infrastructure.ResidentialBuilding;
import model.people.Citizen;
import model.units.Ambulance;
import model.units.DiseaseControlUnit;
import model.units.Evacuator;
import model.units.FireTruck;
import model.units.GasControlUnit;
import model.units.Unit;
import simulation.Rescuable;
import simulation.Simulator;
import view.GridButton;
import view.NextCycleButton;
import view.RescueView;
import view.UnitButton;

//nahlaaaaaaaa
public class CommandCenter implements SOSListener, ActionListener, MouseListener {

	private Simulator engine;
	private ArrayList<ResidentialBuilding> visibleBuildings;
	private ArrayList<Citizen> visibleCitizens;
	private RescueView view;
	private JButton[][] grid;
	private Rescuable[][] rescuables;
	private ArrayList<Unit> emergencyUnits;
	private ArrayList<Unit> ambulances;
	private ArrayList<Unit> firetrucks;
	private ArrayList<Unit> diseasecontrols;
	private ArrayList<Unit> gascontrols;
	private ArrayList<Unit> evacuators;
	private Clip clip;
	private ImageIcon img;
	
	public CommandCenter() throws Exception {

		grid = new GridButton[10][10];
		engine = new Simulator(this);
		visibleBuildings = new ArrayList<ResidentialBuilding>();
		visibleCitizens = new ArrayList<Citizen>();
		emergencyUnits = engine.getEmergencyUnits();
		rescuables = new Rescuable[10][10];
		ambulances = new ArrayList<Unit>();
		firetrucks = new ArrayList<Unit>();
		diseasecontrols = new ArrayList<Unit>();
		gascontrols = new ArrayList<Unit>();
		evacuators = new ArrayList<Unit>();

		view = new RescueView();
		initializeMenuBar();
		
		img=new ImageIcon("totally.jpeg");

		for (int i = 0; i < grid.length; i++) {
			for (int j = 0; j < grid[i].length; j++) {

				JButton b = new GridButton("  ");
				grid[i][j] = b;

				b.addActionListener(this);
				b.addMouseListener(this);

				// UNDERLINING WHEN HOVERING
				// b.addMouseListener(new java.awt.event.MouseAdapter() {
				//
				//
				// public void mouseEntered(java.awt.event.MouseEvent evt) {
				//
				// originalFont = b.getFont();
				// Map attributes = originalFont.getAttributes();
				// attributes.put(TextAttribute.UNDERLINE,
				// TextAttribute.UNDERLINE_ON);
				// b.setFont(originalFont.deriveFont(attributes));
				// if(instanceof )
				// view.citizeninfo(this);
				// }
				//
				// public void mouseExited(java.awt.event.MouseEvent evt) {
				// b.setFont(originalFont);
				//
				// }
				// });

				view.addButton(b, i, j);

			}
		}

		JButton nextcyclebtn = new NextCycleButton(view.getCurrentCycle(), view);
		view.addCycleButton(nextcyclebtn);
		nextcyclebtn.addActionListener(this);

		view.getFrame().setVisible(true);

		// create available units buttons
		for (int i = 0; i < emergencyUnits.size(); i++) {
			JButton b;
			String x = emergencyUnits.get(i).getUnitName();

			switch (x) {
			case "Ambulance":
				ImageIcon amb = new ImageIcon("ambo.jpg");
				ambulances.add(emergencyUnits.get(i));

				b = new UnitButton(i);
				b.setText(null);
				b.setIcon(amb);
				b.addMouseListener(this);
				if (ambulances.size() == 1)
					view.addUnitsButton(b);
				// b.setIcon(null);
				// b.setIcon(evc);

				// b.add(new PopupMenu("cdd"));

				break;
			case "Disease Control Unit":
				diseasecontrols.add(emergencyUnits.get(i));
				ImageIcon dis = new ImageIcon("syringe.jpg");
				b = new UnitButton(i);
				b.setText(null);
				b.setIcon(dis);
				b.addMouseListener(this);
				if (diseasecontrols.size() == 1)
					view.addUnitsButton(b);

				break;
			case "Gas Control Unit":
				gascontrols.add(emergencyUnits.get(i));
				ImageIcon gas = new ImageIcon("images.png");

				b = new UnitButton(i);
				b.setText(null);
				b.setIcon(gas);
				b.addMouseListener(this);
				if (gascontrols.size() == 1)
					view.addUnitsButton(b);
				break;
			case "Fire Truck":
				firetrucks.add(emergencyUnits.get(i));
				ImageIcon fire = new ImageIcon("firetruck.jpg");
				b = new UnitButton(i);
				b.setText(null);
				b.setIcon(fire);
				b.addMouseListener(this);
				if (firetrucks.size() == 1)
					view.addUnitsButton(b);

				break;
			case "Evacuator":
				evacuators.add(emergencyUnits.get(i));
				ImageIcon evac = new ImageIcon("saraevac.jpeg");
				b = new UnitButton(i);
				b.setText(null);
				b.setIcon(evac);
				b.addMouseListener(this);
				if (evacuators.size() == 1)
					view.addUnitsButton(b);

				break;
			default:
				b = new UnitButton(i);
				b.addMouseListener(this);

				break;

			}

			b.addActionListener(this);
			b.setPreferredSize(new Dimension(100, 100));

		}

	}

	@Override
	public void receiveSOSCall(Rescuable r) {

		if (r instanceof ResidentialBuilding) {

			if (!visibleBuildings.contains(r))
				visibleBuildings.add((ResidentialBuilding) r);

		} else {

			if (!visibleCitizens.contains(r))
				visibleCitizens.add((Citizen) r);
		}

	}

	public void addVisibleBuilding() {
		for (int i = 0; i < visibleBuildings.size(); i++) {
			ResidentialBuilding r = visibleBuildings.get(i);
			int x = r.getLocation().getX();
			int y = r.getLocation().getY();
			rescuables[x][y] = r;
			// grid[x][y].addActionListener(this);
			view.addBuildingGrid(x, y, r);
		}
	}

	public void addVisibleCitizen() {
		for (int i = 0; i < visibleCitizens.size(); i++) {
			Citizen r = visibleCitizens.get(i);
			int x = r.getLocation().getX();
			int y = r.getLocation().getY();
			Boolean isoccupant = false;
			// grid[x][y].addActionListener(this);
			for (int j = 0; j < visibleBuildings.size(); j++) {
				if (x == visibleBuildings.get(j).getLocation().getX()
						&& y == visibleBuildings.get(j).getLocation().getY())
					isoccupant = true;
			}
			if (!isoccupant) {
				rescuables[x][y] = r;
				view.addCitizenGrid(x, y,r.getDisaster());
			}

		}

	}

	public void addVisibleUnit() {
		// for (int i = 0; i < engine.getEmergencyUnits().size(); i++) {
		// Unit r = engine.getEmergencyUnits().get(i);
		// int x = r.getLocation().getX();
		// int y = r.getLocation().getY();
		view.addUnitGrid(this.getotherUnits());

		// }
	}

	public void actionPerformed(ActionEvent e) {
		// // get the JButton that was clicked

		JButton currbtn = (JButton) e.getSource();
		if (currbtn instanceof NextCycleButton) {
			view.makeCurrentCycle(view.getCurrentCycle() + 1);
			engine.nextCycle();
			int x = engine.calculateCasualties();
			view.setCasualties(x);
			addVisibleBuilding();
			addVisibleCitizen();
			addVisibleUnit();
			updatelog();

			if (engine.checkGameOver()) {
				// JOptionPane pane=new JOptionPane();
				// pane.
				//
				// JOptionPane.showMessageDialog(
				// view.getFrame(),
				// "GAME OVER \n Your Score is "
				// + engine.calculateCasualties());
				String endgame[] = { "Replay", "Exit" };
				ImageIcon image= new ImageIcon("jake.gif");
				int sofia = JOptionPane.showOptionDialog(null, "Game Over",
						"GAME OVER \n Your Score is " + engine.calculateCasualties(), JOptionPane.CLOSED_OPTION,
						JOptionPane.INFORMATION_MESSAGE, image, endgame, endgame[0]);
				if (sofia == 1) {
					System.exit(0);
				}
				if (sofia == 0) {

					view.getFrame().setVisible(false);

					try {
						engine = new Simulator(this);
					} catch (Exception e1) {
						// TODO Auto-generated catch block
						e1.printStackTrace();
					}
					try {
						new CommandCenter();
					} catch (Exception e1) {
						// TODO Auto-generated catch block
						e1.printStackTrace();
					}

					// System.exit(0);

				}

			}

		}
		if (currbtn instanceof GridButton && (currbtn.getIcon() != null || currbtn.getText() != "  "
				|| ((this.getindexX(grid, currbtn) == 0) && (this.getindexY(grid, currbtn) == 0)))) {
			Unit currUnit = null;
			String[] labels = { "RESCUE ", "Get Information" };
			
		
			int sara = JOptionPane.showOptionDialog(null, "info or respond", "Available Units",
					JOptionPane.DEFAULT_OPTION, JOptionPane.INFORMATION_MESSAGE, img, labels, labels[0]);
			int indexX = this.getindexX(grid, currbtn);
			int indexY = this.getindexY(grid, currbtn);
			Rescuable resc = rescuables[indexX][indexY];

			if (sara == 0) {
				if (resc instanceof ResidentialBuilding) {
					ResidentialBuilding bul = (ResidentialBuilding) resc;
					ArrayList<Citizen> badocc = new ArrayList<Citizen>();

					for (int i = 0; i < bul.getOccupants().size(); i++) {
						if (bul.getOccupants().get(i).getDisaster() != null)
							badocc.add(bul.getOccupants().get(i));
					}

					if (badocc.size() > 0) {
						int badoccsize = badocc.size();
						String[] bulocc = new String[badoccsize + 1];
						bulocc[0] = "Save The Building";
						for (int n = 1; n < bulocc.length; n++) {
							bulocc[n] = "Save occupant" + badocc.get(n - 1).getName() + " from "
									+ badocc.get(n - 1).getDisaster().toString();
						}
						int save = JOptionPane.showOptionDialog(null, "choose who to save", "WHO DO YOU WANT TO SAVE",
								JOptionPane.DEFAULT_OPTION, JOptionPane.INFORMATION_MESSAGE, img, bulocc, bulocc[0]);
						if (save > 0) {
							resc = badocc.get(save - 1);
						}
					}

				}

				ImageIcon amb = new ImageIcon("ambo.jpg");
				ImageIcon dis = new ImageIcon("syringe.jpg");
				ImageIcon gas = new ImageIcon("images.png");
				ImageIcon evac = new ImageIcon("saraevac.jpeg");
				ImageIcon fire = new ImageIcon("firetruck.jpg");

				ImageIcon[] options = { amb, dis, evac, fire, gas };

				int i = JOptionPane.showOptionDialog(null, "pick a unit", "Available Units", JOptionPane.DEFAULT_OPTION,
						JOptionPane.INFORMATION_MESSAGE, img, options, options[0]);
				String type = "";
				if (resc instanceof Citizen)
					type = "citizen";
				else
					type = "building";

				switch (i) {
				case 0:
					int size = ambulances.size();
					if (size > 1) {
						String[] a = new String[size];
						int l;
						for (l = 0; l < a.length; l++) {
							String x = "id: " + ambulances.get(l).getUnitID() + " \n state:"
									+ ambulances.get(l).getState();
							a[l] = x;
						}

						int k = JOptionPane.showOptionDialog(null, "pick a unit", "Available Units",
								JOptionPane.DEFAULT_OPTION, JOptionPane.INFORMATION_MESSAGE, null, a, a[0]);
						currUnit = ambulances.get(k);
					}

					else {
						for (int j = 0; j < engine.getEmergencyUnits().size(); j++) {
							if (engine.getEmergencyUnits().get(j) instanceof Ambulance) {
								currUnit = engine.getEmergencyUnits().get(j);
							}

						}
					}

					try {
						currUnit.respond(resc);

					} catch (IncompatibleTargetException ex) {
						JOptionPane.showMessageDialog(view.getFrame(),
								"You cannot treat a " + type + "with a " + currUnit.getUnitName());
					} catch (CannotTreatException ex) {
						JOptionPane.showMessageDialog(view.getFrame(), "Cannot be treated ");

					}
					break;

				case 1:
					int size1 = diseasecontrols.size();
					if (size1 > 1) {
						String[] dis1 = new String[size1];
						int l1;
						for (l1 = 0; l1 < dis1.length; l1++) {
							String x = "id: " + diseasecontrols.get(l1).getUnitID() + " \n state:"
									+ diseasecontrols.get(l1).getState();
							dis1[l1] = x;
						}

						int d = JOptionPane.showOptionDialog(null, "pick a unit", "Available Units",
								JOptionPane.DEFAULT_OPTION, JOptionPane.INFORMATION_MESSAGE, null, dis1, dis1[0]);
						currUnit = diseasecontrols.get(d);
					}

					else {
						for (int j = 0; j < engine.getEmergencyUnits().size(); j++) {
							if (engine.getEmergencyUnits().get(j) instanceof DiseaseControlUnit) {
								currUnit = engine.getEmergencyUnits().get(j);
							}

						}
					}

					try {
						currUnit.respond(resc);

					} catch (IncompatibleTargetException ex) {
						JOptionPane.showMessageDialog(view.getFrame(),
								"You cannot treat a " + type + "with a " + currUnit.getUnitName());
					} catch (CannotTreatException ex) {
						JOptionPane.showMessageDialog(view.getFrame(), "Cannot be treated ");

					}
					break;

				case 2:
					int size2 = evacuators.size();
					if (size2 > 1) {
						String[] a1 = new String[size2];
						int l1;
						for (l1 = 0; l1 < a1.length; l1++) {
							String x = "id: " + evacuators.get(l1).getUnitID() + " \n state:"
									+ evacuators.get(l1).getState();
							a1[l1] = x;
						}

						int k1 = JOptionPane.showOptionDialog(null, "pick a unit", "Available Units",
								JOptionPane.DEFAULT_OPTION, JOptionPane.INFORMATION_MESSAGE, null, a1, a1[0]);
						currUnit = evacuators.get(k1);
					}

					else {
						for (int j = 0; j < engine.getEmergencyUnits().size(); j++) {
							if (engine.getEmergencyUnits().get(j) instanceof Evacuator) {
								currUnit = engine.getEmergencyUnits().get(j);
							}

						}
					}

					try {
						currUnit.respond(resc);

					} catch (IncompatibleTargetException ex) {
						JOptionPane.showMessageDialog(view.getFrame(),
								"You cannot treat a " + type + "with a " + currUnit.getUnitName());
					} catch (CannotTreatException ex) {
						JOptionPane.showMessageDialog(view.getFrame(), "Cannot be treated ");

					}
					break;
				case 3:
					int size3 = firetrucks.size();
					if (size3 > 1) {
						String[] a1 = new String[size3];
						int l1;
						for (l1 = 0; l1 < a1.length; l1++) {
							String x = "id: " + firetrucks.get(l1).getUnitID() + " \n state:"
									+ firetrucks.get(l1).getState();
							a1[l1] = x;
						}

						int k1 = JOptionPane.showOptionDialog(null, "pick a unit", "Available Units",
								JOptionPane.DEFAULT_OPTION, JOptionPane.INFORMATION_MESSAGE, null, a1, a1[0]);
						currUnit = firetrucks.get(k1);
					}

					else {
						for (int j = 0; j < engine.getEmergencyUnits().size(); j++) {
							if (engine.getEmergencyUnits().get(j) instanceof FireTruck) {
								currUnit = engine.getEmergencyUnits().get(j);
							}

						}
					}
					try {
						currUnit.respond(resc);

					} catch (IncompatibleTargetException ex) {
						JOptionPane.showMessageDialog(view.getFrame(),
								"You cannot treat a " + type + "with a " + currUnit.getUnitName());
					} catch (CannotTreatException ex) {
						JOptionPane.showMessageDialog(view.getFrame(), "Cannot be treated ");

					}
					break;

				case 4:
					int size4 = gascontrols.size();
					if (size4 > 1) {
						String[] gas1 = new String[size4];
						int l1;
						for (l1 = 0; l1 < gas1.length; l1++) {
							String x = "id: " + gascontrols.get(l1).getUnitID() + " \n state:"
									+ gascontrols.get(l1).getState();
							gas1[l1] = x;
						}

						int k1 = JOptionPane.showOptionDialog(null, "pick a unit", "Available Units",
								JOptionPane.DEFAULT_OPTION, JOptionPane.INFORMATION_MESSAGE, null, gas1, gas1[0]);
						currUnit = gascontrols.get(k1);
					}

					else {
						for (int j = 0; j < engine.getEmergencyUnits().size(); j++) {
							if (engine.getEmergencyUnits().get(j) instanceof GasControlUnit) {
								currUnit = engine.getEmergencyUnits().get(j);
							}

						}
					}

					try {
						currUnit.respond(resc);

					} catch (IncompatibleTargetException ex) {
						JOptionPane.showMessageDialog(view.getFrame(),
								"You cannot treat a " + type + " with a(n) " + currUnit.getUnitName());
					} catch (CannotTreatException ex) {
						JOptionPane.showMessageDialog(view.getFrame(), "Cannot be treated ");

					}
					break;
				}
			} else if (sara == 1) {

				int r = getindexX(grid, currbtn);
				int t = getindexY(grid, currbtn);
				// System.out.println(i + " " + j );
				if (currbtn instanceof GridButton) {

					if (rescuables[r][t] instanceof Citizen) {
						view.addcitizeninfo((Citizen) rescuables[r][t]);
						// JOptionPane.showMessageDialog(view.getFrame(),
						// "aanacbsjk OVER");
					}

					if (rescuables[r][t] instanceof ResidentialBuilding) {

						view.addbuildinginfo(((ResidentialBuilding) rescuables[r][t]));
						// JOptionPane.showMessageDialog(view.getFrame(),
						// "aanacbsjk OVER");
					}

					if (r == 0 && t == 0) {
						view.addunitbaseinfo(this.getBaseUnits());
					}
				}

			}
		}
		if (currbtn instanceof UnitButton) {
			ArrayList<Unit> list;
			int i = ((UnitButton) currbtn).getbutIndex();
			Unit u = emergencyUnits.get(i);
			if (u instanceof Ambulance)

				list = this.ambulances;

			else if (u instanceof DiseaseControlUnit)
				list = this.diseasecontrols;
			else if (u instanceof Evacuator)
				list = this.evacuators;
			else if (u instanceof FireTruck)
				list = this.firetrucks;
			else
				list = this.gascontrols;
			view.addunitinfo(list);
		}

	}

	public ArrayList<Unit> getBaseUnits() {
		ArrayList<Unit> out = new ArrayList<Unit>();
		for (int i = 0; i < engine.getEmergencyUnits().size(); i++) {
			if (engine.getEmergencyUnits().get(i).getLocation().getX() == 0
					&& engine.getEmergencyUnits().get(i).getLocation().getY() == 0)
				out.add(engine.getEmergencyUnits().get(i));

		}
		return out;
	}

	public ArrayList<Unit> getotherUnits() {
		ArrayList<Unit> out = new ArrayList<Unit>();
		for (int i = 0; i < engine.getEmergencyUnits().size(); i++) {
			if (engine.getEmergencyUnits().get(i).getLocation().getX() != 0
					&& engine.getEmergencyUnits().get(i).getLocation().getY() != 0)
				out.add(engine.getEmergencyUnits().get(i));

		}
		return out;
	}

	// TO BE CONTINUED
	public void updatelog() {
		String t = " ";
		t = engine.getLogDisasters() + "\n" + engine.getLogbuildings() + "\n" + engine.getLogcitizens();
		view.updatelogview(t);
	}

	@Override
	public void mouseClicked(MouseEvent e) {
		// TODO Auto-generated method stub

	}

	@Override
	public void mousePressed(MouseEvent e) {
		// TODO Auto-generated method stub

	}

	@Override
	public void mouseReleased(MouseEvent e) {
		// TODO Auto-generated method stub

	}

	@Override

	public void mouseEntered(MouseEvent e) {
		JButton b = (JButton) e.getSource();
		if (b instanceof GridButton) {
			// URL urlClick=this.class.getResource("alaema.wav");
			// click=Applet.newAudioClip(urlClick);
			// click.loop();
			Rescuable x = rescuables[this.getindexX(grid, b)][this.getindexY(
					grid, b)];
			if (x instanceof Citizen) {
				Disaster d = x.getDisaster();
				if (d instanceof Injury) {
					//playsound("henedy.wav");

				}
				if (d instanceof Infection) {
					playsound("infection.wav");
				}
			} else if (x instanceof ResidentialBuilding) {
				Disaster d = x.getDisaster();
				if (d instanceof Fire) {
				playsound("firewav1.wav");
				} else if (d instanceof GasLeak) {
					playsound("gasleak.wav");

				} else if (d instanceof Collapse) {
					playsound("collapse.wav");

				}
			}
		}
		else if(b instanceof UnitButton){
			UnitButton u=(UnitButton)b;
			int i=u.getbutIndex();
			switch (i){
			case 0:playsound("ambu.wav");break;
			case 1:playsound("ouch.wav");break;
			case 2:playsound("carhorn.wav");break;
			case 3:playsound("drivetFire.wav");break;
			case 4:playsound("gascontrol.wav");break;
			
			}
		}
	}

	public int getindexX(JButton[][] grid, JButton b) {

		for (int i = 0; i < grid.length; i++)
			for (int j = 0; j < grid[i].length; j++) {
				if (grid[i][j].equals(b)) {
					return i;
				}
			}
		return 0;
	}

	public int getindexY(JButton[][] grid, JButton b) {

		for (int i = 0; i < grid.length; i++)
			for (int j = 0; j < grid[i].length; j++) {
				if (grid[i][j].equals(b)) {
					return j;
				}
			}
		return 0;
	}

	public void playsound(String s) {
		File soundFile = new File(s);

		try {
			AudioInputStream audioIn = AudioSystem.getAudioInputStream(soundFile);
			clip = AudioSystem.getClip();
			clip.open(audioIn);
			clip.start();
			clip.loop(Clip.LOOP_CONTINUOUSLY);

		} catch (UnsupportedAudioFileException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();

		} catch (IOException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		} catch (LineUnavailableException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
	}

	@Override
	public void mouseExited(MouseEvent e) {
		JButton b = (JButton) e.getSource();
		if (clip != null && clip.isActive())
			clip.stop();

	}
	
	private void initializeMenuBar() {
		JMenuBar menuBar = new JMenuBar();
		JMenu menu = new JMenu("File");
		JMenuItem newGame = new JMenuItem("New Game!");
		JMenuItem quit = new JMenuItem("Quit..");

		newGame.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				restartgame();

			}
		});

		quit.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				System.exit(0);

			}
		});

		menu.add(newGame);
		menu.add(quit);
		menuBar.add(menu);
		view.getFrame().setJMenuBar(menuBar);
	}
	
	public void restartgame() {
		view.getFrame().setVisible(false);

		try {
			engine = new Simulator(this);
		} catch (Exception e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		try {
			new CommandCenter();
		} catch (Exception e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
	}

	@SuppressWarnings("unused")
	public static void main(String[] args) throws Exception {

		CommandCenter c = new CommandCenter();

	}

}
