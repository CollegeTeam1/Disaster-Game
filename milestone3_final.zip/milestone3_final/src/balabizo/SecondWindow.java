package balabizo;
import javax.swing.*;


public class SecondWindow extends JFrame {


	public SecondWindow()
	{
		super();
        setSize(400,100);
        setTitle("First Window");
        JLabel l = new JLabel("Hello World");
        add(l);
        WindowDestroyer myListener = new WindowDestroyer();
        addWindowListener(myListener);
	}


     public static void main(String[] args) {

     	SecondWindow w1 = new SecondWindow();
     	w1.setVisible(true);

     	SecondWindow w2 = new SecondWindow();
     	w2.setVisible(true);











         }
}








//