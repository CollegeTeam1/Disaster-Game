package balabizo;
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
public class ButtonDemo extends JFrame implements ActionListener
{

    public static void main(String[] args)
    { ButtonDemo buttonGUI = new ButtonDemo();
	buttonGUI.setVisible(true);
    }


    public ButtonDemo()
{
    super();
    setSize(400,100);
    getContentPane().setLayout(new FlowLayout());
    JButton button1 = new JButton("Rot");
    button1.addActionListener(this);
    button1.setActionCommand("Red");

    getContentPane().add(button1);
    JButton button2 = new JButton("Schwarz");

    //button2.setActionCommand("Black");

    button2.addActionListener(this);
    getContentPane().add(button2);
    setTitle("Second Window");
    getContentPane().setBackground(Color.BLUE);
    WindowDestroyer myListener = new WindowDestroyer();
    addWindowListener(myListener);
}

    public void actionPerformed(ActionEvent e)
    {
	if (e.getActionCommand().equals("Red"))
            getContentPane().setBackground(Color.RED);
        else if (e.getActionCommand().equals("Black"))
            getContentPane().setBackground(Color.BLACK);
    }

}
