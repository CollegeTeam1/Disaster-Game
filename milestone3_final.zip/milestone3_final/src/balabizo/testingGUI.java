package balabizo;

import javax.swing.*;
import java.awt.*;

public class testingGUI {

	public static void main(String[] args) {
		JFrame frame = new JFrame();
		frame.setVisible(true);
		frame.setSize(500, 500);
		// f.setDefaultCloseOperation(EXIT_ON_CLOSE);
		Container cp = frame.getContentPane();
		JPanel p = new JPanel();
		p.setBackground(Color.BLACK);
		p.setOpaque(true);
		p.setBounds(100, 100, 40, 40);
		//cp.add(p);

		JPanel leftPanel = new JPanel();
		leftPanel.setBackground(Color.RED);
		leftPanel.setOpaque(true);
		leftPanel.setPreferredSize(new Dimension(100, 600));
		
		JPanel northPanel = new JPanel();
		northPanel.setPreferredSize(new Dimension(800, 100));
		p.setBackground(Color.BLUE);
		p.setOpaque(true);
		
		JPanel bottomPanel = new JPanel();
		bottomPanel.setPreferredSize(new Dimension(800, 100));
		p.setBackground(Color.PINK);
		p.setOpaque(true);

		JPanel centerPanel = new JPanel();
		centerPanel.setPreferredSize(new Dimension(600, 600));
		centerPanel.setMinimumSize(new Dimension(600, 600));
		p.setBackground(Color.GREEN);
		p.setOpaque(true);

		JPanel buttonPanel = new JPanel();
		p.setBackground(Color.PINK);
		p.setOpaque(true);

		buttonPanel.setLayout(new GridLayout(3, 1));
		buttonPanel.setPreferredSize(new Dimension(100, 600));
		buttonPanel.setMaximumSize(new Dimension(100, 600));

		JButton reset = new JButton();
		reset.setText("Reset");
		reset.setSize(100, 180);
		JButton pause = new JButton();
		pause.setText("Pause");
		pause.setSize(100, 180);
		JButton quit = new JButton();
		quit.setText("Quit");
		quit.setSize(100, 180);

		cp.add(northPanel, BorderLayout.NORTH);
		cp.add(leftPanel, BorderLayout.WEST);
		cp.add(centerPanel, BorderLayout.CENTER);
		cp.add(buttonPanel, BorderLayout.EAST);
		cp.add(bottomPanel, BorderLayout.SOUTH);

		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.pack();
		frame.setLocationRelativeTo(null);
		frame.setVisible(true);

		JButton b = new JButton("me");
		b.setBackground(Color.blue);
		b.setBounds(10, 10, 70, 70);
		// b.setPreferredSize(new Dimension(2,2));
		//p.add(b);

	}

}
