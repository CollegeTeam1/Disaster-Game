package balabizo;
import javax.swing.*;

public class FirstWindow {
     public static void main(String[] args) {
         JFrame myWindow = new JFrame();
         myWindow.setSize(400,100);
         myWindow.setVisible(true);

		 JLabel l = new JLabel("Hello World");
         myWindow.add(l);
         JLabel l2 = new JLabel("Hello GUC");
         myWindow.add(l2);


         myWindow.setTitle("First Window");

         WindowDestroyer myListener = new WindowDestroyer();
         myWindow.addWindowListener(myListener);

         }
}








//