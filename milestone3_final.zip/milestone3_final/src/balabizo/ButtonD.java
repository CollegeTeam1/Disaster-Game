package balabizo;
import java.awt.Color;
import java.awt.FlowLayout;

import javax.swing.JButton;
import javax.swing.JFrame;
public class ButtonD extends JFrame
{

    public static void main(String[] args)
    { ButtonD buttonGUI = new ButtonD();
	buttonGUI.setVisible(true);
    }


    public ButtonD()
{
    super();
    setSize(400,100);
    getContentPane().setLayout(new FlowLayout());
    JButton button1 = new JButton("Red");
    getContentPane().add(button1);
    JButton button2 = new JButton("Black");
    getContentPane().add(button2);
    JButton button3 = new JButton("Magenta");
    getContentPane().add(button3);
    setTitle("Second Window");
    getContentPane().setBackground(Color.BLUE);
    WindowDestroyer myListener = new WindowDestroyer();
    addWindowListener(myListener);
}



}
