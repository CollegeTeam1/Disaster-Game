package view;

import java.awt.Font;

import javax.swing.JButton;

public class GridButton extends JButton {
//	private Font originalFont;

	public GridButton() {
		super();
		
		// TODO Auto-generated constructor stub
	}

	public GridButton(String text) {
		super(text);
	//	originalFont=this.getFont();
		// TODO Auto-generated constructor stub
	}

//	public Font getOriginalFont() {
//		return originalFont;
//	}
//
//	public void setOriginalFont(Font originalFont) {
//		this.originalFont = originalFont;
//	}
//	

}
