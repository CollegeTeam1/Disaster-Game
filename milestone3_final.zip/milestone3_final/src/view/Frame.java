package view;

import java.awt.Color;

import javax.swing.JFrame;


@SuppressWarnings("serial")
public class Frame extends JFrame{
	
	public Frame(String title) {
		//this.setVisible(true);
		
		//Dimension screen = Toolkit.getDefaultToolkit().getScreenSize();
//		int x = (int) (screen.getWidth() );
//		int y = (int) (screen.getHeight() );
		//setLocation(x, y); 
		//this.setSize(1000, 1200);
		
		this.setResizable(false);
		this.setTitle(title);
		this.setDefaultCloseOperation(EXIT_ON_CLOSE);
	
//		Toolkit tk = Toolkit.getDefaultToolkit();
//		Dimension screenSize = tk.getScreenSize();
//		int screenHeight = screenSize.height;
//		int screenWidth = screenSize.width;
//		setSize(screenWidth / 2, screenHeight / 2);
//		setLocation(screenWidth / 4, screenHeight / 4);
	}

	

}
