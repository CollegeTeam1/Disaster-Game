package view;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Container;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;

import model.disasters.Collapse;
import model.disasters.Disaster;
import model.disasters.Fire;
import model.disasters.GasLeak;
import model.disasters.Infection;
import model.disasters.Injury;
import model.infrastructure.ResidentialBuilding;
import model.people.Citizen;
import model.units.Ambulance;
import model.units.DiseaseControlUnit;
import model.units.Evacuator;
import model.units.FireTruck;
import model.units.GasControlUnit;
import model.units.Unit;

public class RescueView {
	private Frame frame;
	private JPanel unitPanel;
	private JPanel city;
	private JPanel cycles;
	private JPanel info;
	private JButton[][] grid;
	private Container cp;
	private JLabel currentCycle_lbl;
	private JButton nextCycle_btn;
	private JLabel casualties;
	private int currentCycle;
	private JTextArea information;
	private JTextArea log;
	private JScrollPane scroller;
	private JScrollPane scroller2;
	private JPanel logPanel;
	private JPanel otherPanel;
	private JMenuBar menuBar;

	public RescueView() {
		this.frame = new Frame("RESCUE");
		cp = frame.getContentPane();
		frame.isResizable();
		frame.setResizable(true);
		frame.setIconImage(new ImageIcon(getClass().getResource("/images/totallyspies.jpeg")).getImage());
		int screenWidth= java.awt.GraphicsEnvironment.getLocalGraphicsEnvironment().getMaximumWindowBounds().width;
		int screenHeight=java.awt.GraphicsEnvironment.getLocalGraphicsEnvironment().getMaximumWindowBounds().height;
		int ss=screenHeight-screenHeight%100;
		int x=ss;
		while(x%10==0){
			x=x/10;
		}

		int gridHeight=(int)screenHeight-(ss/x);
		int otherWidth=(int)((screenWidth-gridHeight)/2);
		grid = new JButton[10][10];

		// create main panels///////////////////////////////
		this.unitPanel = new JPanel(new GridLayout(6, 0));
		unitPanel.setSize(otherWidth, gridHeight);
		cp.add(unitPanel, BorderLayout.EAST);

		this.city = new JPanel(new GridLayout(10, 10));
		city.setPreferredSize(new Dimension(gridHeight,gridHeight));
		cp.add(city, BorderLayout.CENTER);

		// this.info = new JPanel(new GridLayout(2,0));
		this.info = new JPanel(new BorderLayout());

		info.setPreferredSize(new Dimension(otherWidth, gridHeight));
		cp.add(info, BorderLayout.WEST);

		this.cycles = new JPanel(new FlowLayout());
		cycles.setPreferredSize(new Dimension(800, 50));
		cp.add(cycles, BorderLayout.SOUTH);

		for (int i = 0; i < grid.length; i++) {
			for (int j = 0; j < grid[i].length; j++) {
				JButton b = new JButton("   ");
				grid[i][j] = b;
			}
		}
		// --------------------------------------------------------

		// units section///////////////////////////////////////////
		JLabel availablelbl = new JLabel("Available Units");
		availablelbl.setHorizontalAlignment(0);
		unitPanel.add(availablelbl);

		// JLabel respondinglbl = new JLabel("Responding Units");
		// respondinglbl.setHorizontalAlignment(0);
		// unitPanel.add(respondinglbl);
		//
		// JLabel treatinglbl = new JLabel("Treating Units");
		// treatinglbl.setHorizontalAlignment(0);
		// unitPanel.add(treatinglbl);
		//

		// information section///////////////////////////////////////////

		// text areas
		this.information = new JTextArea();
		information.setEditable(false);
		information.setLineWrap(true);
		information.setText("");

		this.log = new JTextArea();
		log.setEditable(false);
		log.setLineWrap(true);

		// panels
		this.otherPanel = new JPanel();
		this.logPanel = new JPanel();

		// this.logPanel.add(scroller);

		// log = new JTextArea();
		scroller = new JScrollPane(log);
		scroller.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_ALWAYS);
		scroller.setHorizontalScrollBarPolicy(JScrollPane.HORIZONTAL_SCROLLBAR_ALWAYS);
		scroller.setAutoscrolls(true);
		scroller.setSize(100, 100);

		logPanel.setSize(200, 200);
		logPanel.setLayout(new BorderLayout());

		scroller2 = new JScrollPane(information);
		scroller2.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_ALWAYS);
		scroller2.setHorizontalScrollBarPolicy(JScrollPane.HORIZONTAL_SCROLLBAR_ALWAYS);
		scroller2.setAutoscrolls(true);
		scroller2.setSize(300,300);

		otherPanel.setSize(500, 800);
		otherPanel.setLayout(new BorderLayout());

	

		// JLabel infolabel = new JLabel("Information");
		// // otherPanel.add(scroller2);
		// otherPanel.add(infolabel, BorderLayout.NORTH);
//		otherPanel.add(information, BorderLayout.NORTH);

		// infolabel.setHorizontalAlignment(0);

		logPanel.setPreferredSize(new Dimension(250, 200));
		logPanel.add(scroller);
		otherPanel.setPreferredSize(new Dimension(400, 400));
		otherPanel.add(scroller2);
		info.add(otherPanel, BorderLayout.NORTH);
		info.add(logPanel, BorderLayout.SOUTH);

		// info.add(inform, BorderLayout.NORTH);

		// info.add(information,BorderLayout.SOUTH);

		// cycles and casualties
		// section///////////////////////////////////////////
		casualties = new JLabel("number of casualties: 0   ");
		casualties.setBackground(Color.LIGHT_GRAY);
		casualties.setFont(new Font("Arial", Font.BOLD, 15));
		// casualties.setForeground(Color.white);
		casualties.setOpaque(true);

		cycles.add(casualties);

		this.currentCycle_lbl = new JLabel("START GAME --> ");
		currentCycle_lbl.setBackground(Color.lightGray);
		currentCycle_lbl.setOpaque(true);
		currentCycle_lbl.setFont(new Font("Arial", Font.BOLD, 15));

		cycles.add(currentCycle_lbl);

		//menu bar////////////////////////////////
		
		
		
		
		
		// JLabel emptyLabel = new JLabel("     ");
		// cycles.add(emptyLabel);
		frame.setBackground(Color.black);
		frame.setVisible(true);
		frame.pack();
		frame.setLocationRelativeTo(null);

	}

	public void makeCurrentCycle(int current) {

		currentCycle_lbl.setText("cycle number:  " + current + "");
		this.currentCycle++;
	}

	public void setCasualties(int cas) {

		casualties.setText("Number of Casualties:  " + cas + " ");
	}

	public void addBuildingGrid(int x, int y, ResidentialBuilding r) {
		ImageIcon bul;
		Disaster d= r.getDisaster();
		if (r.getStructuralIntegrity() > 0) {
			if(d instanceof Fire)
				bul = new ImageIcon("bulfire.jpg");
			else if(d instanceof GasLeak)
				bul = new ImageIcon("suff.jpg");
			else
				bul = new ImageIcon("build.jpg");
		
	
		}
			
		else
			bul = new ImageIcon("collapsed.jpg");
		
		grid[x][y].setText(null);
		grid[x][y].setIcon(bul);
		
		
		
		

		// grid[x][y].setText("building");

	}

	public void addUnitGrid(ArrayList<Unit> un) {
		for (int i = 0; i < un.size(); i++) {
			Unit u = un.get(i);
			int x = u.getLocation().getX();
			int y = u.getLocation().getY();

			if (u instanceof Ambulance) {
				ImageIcon amb = new ImageIcon("cit+amb.jpg");
				grid[x][y].setIcon(amb);
			}

			else if (u instanceof DiseaseControlUnit) {
				ImageIcon disease = new ImageIcon("citizen+disease.jpg");
				grid[x][y].setIcon(disease);
			}

			else if (u instanceof GasControlUnit) {
				ImageIcon gas = new ImageIcon("gas+build.PNG");
				grid[x][y].setIcon(gas);
			}

			else if (u instanceof FireTruck) {
				grid[x][y].setText(null);
				ImageIcon firetruck = new ImageIcon("fire+truck.jpg");
				grid[x][y].setIcon(firetruck);

			}

			else if (u instanceof Evacuator) {
				ImageIcon evc = new ImageIcon("saraevac.jpeg");
				grid[x][y].setIcon(evc);
			}

		}
		// grid[x][y].setText(grid[x][y].getText() + " Unit");

	}

	// public void updateBase(ArrayList<Unit> baseUnits) {
	//
	//
	//
	//
	// }

	public void addCitizenGrid(int x, int y,Disaster d) {
		ImageIcon cit;
		if(d instanceof Infection)
			 cit = new ImageIcon("infected.png");
		
		else 
			 cit = new ImageIcon("3.jpg");
		
		grid[x][y].setText(null);
		grid[x][y].setIcon(cit);

	}

	public void addButton(JButton b, int i, int j) {

		grid[i][j] = b;

		city.add(b);

	}

	public void addUnitsButton(JButton b) {

		unitPanel.add(b);

	}

	public void addCycleButton(JButton b) {
		this.nextCycle_btn = b;
		cycles.add(nextCycle_btn);

	}

	public void setCurrentCycle(int currentCycle) {
		this.currentCycle = currentCycle;
	}

	public Frame getFrame() {
		return frame;
	}

	public int getCurrentCycle() {
		return currentCycle;
	}
	
	public void addcitizeninfo(Citizen c) {
		if (c != null) {
			// otherPanel.remove(scroller2);

			information.setText(c.toString());

			// otherPanel.add(information);

			// scroller2.add(information);
			// scroller2
			// .setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_ALWAYS);
			// otherPanel.add(scroller2);
			//

		}

	}

	public void addbuildinginfo(ResidentialBuilding c) {

		// otherPanel.remove(scroller2);

		information.setText(c.toString());

//		 otherPanel.add(information);

		// scroller2
		// .setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_ALWAYS);
		// otherPanel.add(scroller2);

	}

	public void addunitbaseinfo(ArrayList<Unit> baseunit) {
		String out = "";
		for (int i = 0; i < baseunit.size(); i++) {
			out += baseunit.get(i).getUnitName() + "\n";
		}
		information.setText(out);
//		otherPanel.add(information);
		// info.add(scroller, BorderLayout.WEST);

	}

	public void addunitinfo(ArrayList<Unit> list) {
		information.setText(null);
		for (int i = 0; i < list.size(); i++) {
			this.information.setText(this.information.getText() + "\n"
					+ list.get(i).toString());
		}

//		otherPanel.add(information);

	}

	public void updatelogview(String t) {
		this.log.setText(t);
		logPanel.add(scroller);

	}

	public void removeInfo() {
		information.setText("   ");

	}

	public JTextArea getLog() {
		return log;
	}

	// public static void main(String[] args) {
	// SwingUtilities.invokeLater(new Runnable() {
	//
	// @Override
	// public void run() {
	//
	// RescueView v = new RescueView();
	// v.addBuildingGrid(8, 8);
	// v.addCitizenGrid(7, 8);
	//
	// }
	//
	// });
	//
	//
	// }
	//
}
