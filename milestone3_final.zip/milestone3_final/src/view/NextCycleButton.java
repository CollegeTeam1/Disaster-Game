package view;

import javax.swing.JButton;

public class NextCycleButton extends JButton  {
	private int currentcycle;
	private RescueView view;
	public NextCycleButton(int c,RescueView view) {
		this.view=view;
		currentcycle = c;
		this.setText("next cycle");
		
	}

//	@Override
//	public void actionPerformed(ActionEvent e) {
//		JButton nextcyclebutton = (JButton) e.getSource();
//		view.setCurrentCycle(currentcycle++);
//		
//
//		
//	}
}
