package view;

import javax.swing.JButton;

import model.units.Unit;

public class UnitButton extends JButton {
	private int index;

	public UnitButton(int index) {
		super();
		this.index = index;

		// TODO Auto-generated constructor stub
	}

	public UnitButton(String text) {
		super(text);
		// TODO Auto-generated constructor stub
	}

	public int getbutIndex() {
		return index;
	}

}
